public class IceClass {
    public IceClass() {
        System.out.println("Ice 객체 생성자 호출되었습니다.");

    }
}
