public class AppleClass {
    public AppleClass() {
        System.out.println("Apple 객체 생성자 호출되었습니다.");

    }
}
