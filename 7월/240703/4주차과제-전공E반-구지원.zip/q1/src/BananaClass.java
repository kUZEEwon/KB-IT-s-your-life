public class BananaClass {
    public BananaClass() {
        System.out.println("Banana 객체 생성자 호출되었습니다.");

    }
}
