package _0620_class_basic.basic_q2_class;

public class TV {
    public int ch;
    public int vol;
    public boolean onOff;

    public void 채널을바꾸다(){
        int change = 1;
        System.out.println(ch + change + "번호로 바꾸다.");
    }

    public void setCh() {
        System.out.println(vol +"을 키워서 동영상을 보다.");
    }
}
