package _0620_class_basic.basic_q4_class;

class Item {
    String name;
    double price;

    void setName(String name) {
        this.name = name;
    }

    String getName() {
        return name;
    }

    void setPrice(double price) {
        this.price = price;
    }

    double getPrice() {
        return price;
    }
}
