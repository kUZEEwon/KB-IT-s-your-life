package controller;

import dao.MemberDao;
import dto.MemberDto;
import net.sf.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/Member")
public class MemberController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doProc(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doProc(req, resp);
    }

    public void doProc(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html; charset=UTF-8");

        MemberDao dao = MemberDao.getInstance();

        String param = req.getParameter("param");
        if (param.equals("login")) {
            resp.sendRedirect("login.jsp");
        }
        else if (param.equals("account")) {
            resp.sendRedirect("account.jsp");
        }
        else if(param.equals("idcheck")) {  // ajax
            System.out.println("idcheck");
            String id = req.getParameter("id");
            System.out.println(id);

            //MemberDao dao = MemberDao.getInstance();
            boolean isS = dao.getId(id);
            String msg = "YES";
            if(isS == true){   // 사용할 수 있는 아이디
                msg = "NO";
            }

            // ajax로 보낼때
            JSONObject obj = new JSONObject();
            obj.put("msg", msg);    // 짐싸!

            resp.setContentType("application/x-json; charset=utf-8");
            resp.getWriter().print(obj);    // 보내다
        }
        else if(param.equals("accountAf")) {
            String id = req.getParameter("id");
            String pw = req.getParameter("pw");
            String name = req.getParameter("name");
            String email = req.getParameter("email");

            // MemberDao dao = MemberDao.getInstance();
            boolean isS = dao.insertMember(new MemberDto(id, pw, name, email, 0));
            if(isS == true){
                //resp.sendRedirect("login.jsp");

                req.setAttribute("message", "MEMBER_YES");  // 짐싸!
                req.getRequestDispatcher("message.jsp").forward(req, resp); // 잘가

            }else{
                //resp.sendRedirect("account.jsp");

                req.setAttribute("message", "MEMBER_NO");  // 짐싸!
                req.getRequestDispatcher("message.jsp").forward(req, resp); // 잘가
            }
        } else if (param.equals("loginAf")) {

            String id = req.getParameter("id");
            String pw = req.getParameter("pw");

            MemberDto login = dao.login(id, pw);
            if (login != null && !login.getId().equals("")) {

                // session 에 저장
                req.getSession().setAttribute("login", login);
                req.getSession().setMaxInactiveInterval(60 * 60 * 24 * 7);

                req.setAttribute("login", "LOGIN_OK");
                req.getRequestDispatcher("message.jsp").forward(req, resp);
            }else {
                req.setAttribute("login", "LOGIN_NG");
                req.getRequestDispatcher("message.jsp").forward(req, resp);
            }
        }

    }
}








