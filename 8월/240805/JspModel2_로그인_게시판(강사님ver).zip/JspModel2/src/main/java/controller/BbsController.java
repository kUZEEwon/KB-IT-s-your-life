package controller;

import dao.BbsDao;
import db.DBConnection;
import dto.BbsDto;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class BbsController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doProc(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doProc(req, resp);
    }

    public void doProc(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html; charset=UTF-8");

        BbsDao dao = BbsDao.getInstance();

        String param = req.getParameter("param");

        if (param.equals("bbslist")) {
            System.out.println("bbslist");

            String category = req.getParameter("category");
            String keyword = req.getParameter("keyword");
            if (category == null || category.equals("")) {
                category = "";
            }
            if (keyword == null || keyword.equals("")) {
                keyword = "";
            }

            List<BbsDto> list = dao.getBbsSearchlist(category, keyword);

            req.setAttribute("list", list); // 짐싸
            req.getRequestDispatcher("bbslist.jsp").forward(req, resp); // 잘가
        }
        else if (param.equals("bbswrite")) {
            resp.sendRedirect("bbswrite.jsp");
        }
        else if (param.equals("bbswriteAf")) {
            String id = req.getParameter("id");
            String title = req.getParameter("title");
            String content = req.getParameter("content");

            boolean isS = dao.bbswrite(new BbsDto(id, title, content));
            String bwm = "BBSWRITE_OK";
            if (!isS) {
                bwm = "BBSWRITE_NG";
            }

            req.setAttribute("bwm", bwm);
            req.getRequestDispatcher("message.jsp").forward(req, resp);
        }
        else if (param.equals("bbsdetail")) {

            int seq = Integer.parseInt(req.getParameter("seq"));

            BbsDto bbs = dao.getBbs(seq);

            req.setAttribute("bbs", bbs);
            req.getRequestDispatcher("bbsdetail.jsp").forward(req, resp);
        }
        else if (param.equals("bbsupdate")) {

            int seq = Integer.parseInt(req.getParameter("seq"));
            System.out.println("seq:" + seq);
            BbsDto bbs = dao.getBbs(seq);
            System.out.println("bbs:" + bbs.toString());

            req.setAttribute("bbs", bbs);
            req.getRequestDispatcher("bbsupdate.jsp").forward(req, resp);
        }
        else if (param.equals("bbsupdateAf")) {
            int seq = Integer.parseInt( req.getParameter("seq") );
            String title = req.getParameter("title");
            String content = req.getParameter("content");

            boolean isS = dao.updateBbs(seq, title, content);
            String bbsupdate = "BBS_UPDATE_OK";
            if(!isS) {
                bbsupdate = "BBS_UPDATE_NO";
            }

            req.setAttribute("seq", seq);
            req.setAttribute("bbsupdate", bbsupdate);

            req.getRequestDispatcher("message.jsp").forward(req, resp);
        }

    }
}
