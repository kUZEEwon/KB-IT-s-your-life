<template>
    <div id="Main">

        <router-view />

    </div>
</template>
<script>
export default {
    name:'Main'
}
</script>

<style>
</style>
