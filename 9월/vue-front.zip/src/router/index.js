import { createWebHistory, createRouter } from 'vue-router' // npm i vue-router@next

import member from '@/router/member/member.js';
import bbs from '@/router/bbs/bbs.js';
import calendar from '@/router/cal/calendar.js';
import fileupdown from '@/router/fileupdown/fileupdown';
import scrlist from '@/router/scr/scrlist.js';

const router = createRouter({
    history: createWebHistory(),
    routes:[
        ...member,
        ...bbs,
        ...calendar,
        ...fileupdown,
        ...scrlist,
    ]
})

export default router;

