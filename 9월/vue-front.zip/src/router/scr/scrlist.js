
import scrlist from '@/components/scr/scrlist.vue'

export default[
    {
        path:"/scrlist",
        name:"scrlist",
        component:scrlist
    },

]