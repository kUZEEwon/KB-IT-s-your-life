
import calendar from '@/components/cal/calendar.vue'

export default[
    {
        path:"/calendar",
        name:"calendar",
        component:calendar
    },

]