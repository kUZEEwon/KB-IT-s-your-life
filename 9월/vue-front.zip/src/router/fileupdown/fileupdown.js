
import fileupdown from '@/components/fileupdown/fileupdown.vue'

export default[
    {
        path:"/fileupdown",
        name:"fileupdown",
        component:fileupdown
    },

]