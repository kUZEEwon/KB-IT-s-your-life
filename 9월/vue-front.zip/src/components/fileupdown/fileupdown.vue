<template>
    <div id="fileupload">
        <br />
        <h3>file upload</h3>

        <input type="file" id="formFile" @change="onFileChange" />

        <button class="btn btn-primary" @click="uploadFileBtn">파일 업로드</button>
        <br />

        <hr />

        <button class="btn btn-primary" @click="downloadFileBtn">파일 다운로드</button>
        <br /><br />
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: "fileupload",
    data() {
        return {
            selectedFile: null,  // 선택한 파일을 저장        
        };
    },
    methods: {

        onFileChange(event) {
            this.selectedFile = event.target.files[0];  // 첫 번째 파일 선택
        },        
        async uploadFileBtn() {
            if (!this.selectedFile) {
                alert("파일을 선택하세요.");
                return;
            }

            const formData = new FormData();
            formData.append('uploadFile', this.selectedFile);

            try {
                const response = await axios.post('http://localhost:9000/pds/fileUpload', formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        "Authorization": 'Bearer ' + sessionStorage.getItem("token") 
                    }
                });
                
                alert(response.data);
                 
            } catch (error) {                
                alert('파일 업로드 실패!');
            }
        },
        async downloadFileBtn(){

            
            try {
                const response = await axios.get("http://localhost:9000/pds/fileDownload", 
                                {   
                                    headers: {                                        
                                        "Authorization": 'Bearer ' + sessionStorage.getItem("token") 
                                    },
                                    params: { 
                                        fileName:"ApiController.txt" 
                                    },
                                    responseType: "blob",  
                                });

                // url 취득
                const url = window.URL.createObjectURL(new Blob([response.data]));
                // a 태그 생성
                const link = document.createElement("a");
                link.href = url;
                link.setAttribute("download", "ApiController.txt");
                document.body.appendChild(link);
                link.click();

            } catch (error) {
                console.error(error);
            }
        }
    }
}
</script>

<style>
</style>