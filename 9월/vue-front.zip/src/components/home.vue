<template>
    <div id="home">
        
        <br/><br/><br/>
        <h1>My Home</h1>     
        <br/><br/>        
        <h1>Welcome to our community!</h1>
        <br/><br/><br/>
        <h3>Your success is our priority.</h3>
        <br/>
        <p>If you need any assistance, don’t hesitate to reach out. We’re here to make your experience with [Your Company] as smooth and enjoyable as possible.</p>

    </div>
</template>

<script>
export default {
    name:'home'
}
</script>

<style>
#home{       
    margin:auto;   
    background-image: url("../assets/coast-city.jpg");        
    text-align: right;
    padding-right: 50px;
    width: 1250px;
    height: 625px;
    background-size : cover;
    color: antiquewhite;
}    
</style>