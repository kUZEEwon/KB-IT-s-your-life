<template>
    <div class="calendar">
        <FullCalendar :options='calendarOptions' ref="cal"/>
        <br />

        <!-- 일정추가 -->
        <button @click='onEventAdded' className="btn btn-primary">일정추가 테스트용</button>
    </div>
</template>

<script>
import FullCalendar from '@fullcalendar/vue3'   
import dayGridPlugin from '@fullcalendar/daygrid' 
import timeGridPlugin from '@fullcalendar/timegrid'
import listMonth from '@fullcalendar/list'

import interactionPlugin from "@fullcalendar/interaction"   // dateClick 

export default {
    components: {
        FullCalendar // make the <FullCalendar> tag available
    },
    data: function () {
        return {
            calendarOptions: {
                // plugins: [dayGridPlugin],
                // initialView: 'dayGridMonth',                
                // events: [
                //     { title: 'Meeting', start: new Date() }
                // ]
                headerToolbar: {
                    left: "prev,next today",   // 좌측버튼
                    center: "title",           // 중앙제목
                    end: "dayGridMonth,timeGridWeek,timeGridDay,listMonth"
                },

                plugins: [dayGridPlugin, timeGridPlugin, listMonth, interactionPlugin], // 플러그인 설정
                initialView: 'dayGridMonth',
                locale: 'ko',
                navLinks: true,
                businessHours: true,
                events: [
                    {
                        title: '점심약속',
                        date: new Date()           // 오늘
                    },
                    {
                        title: '미팅',
                        date: '2024-09-27'
                    },
                    {
                        title: '비즈니스 점심약속',
                        start: '2024-09-16 12:30:00',
                        constraint: '김사장님'
                    },
                    {
                        title: '비즈니스',
                        start: '2024-09-21T16:45:00',
                        constraint: '양사장님',
                        color: '#ff0000'
                    },
                    {
                        title: '워크샵',
                        start: '2024-09-26 10:00:00',
                        end: '2024-09-28 18:00:00',
                        constraint: '사내운동회'
                    },
                    {
                        title: '데이트',
                        start: '2024-09-30 18:00:00',
                        constraint: '영화관람',
                        display: 'background-color',
                        color: '#ff0000'
                    }
                ],
                eventClick: this.eventClick,  // 작성된 이벤트를 클릭시
                dateClick: this.dateClick   // 날짜에 해당하는 <td> 태그를 클릭시

            }
        }
    },
    methods: {
        eventClick(info) {
            //alert('eventClick');
            //alert(JSON.stringify(info))
            //alert(info.event.title)     // 제목
            //alert(info.el.fcSeg.eventRange.ui.constraints)  // 내용
            //alert(info.event.start)     // 날짜

            let date = new Date(info.event.start)
            let year = date.getFullYear()
            let month = date.getMonth()
            let day = date.getDate()
            let hour = date.getHours()
            let minute = date.getMinutes()

            let promise = "날짜: " + year + "/" + month + "/" + day + " "
                + hour + "시 " + minute + "분\n";
            promise += "제목: " + info.event.title + "\n";
            promise += "내용: " + info.el.fcSeg.eventRange.ui.constraints;

            alert(promise);
        },
        dateClick(args) {
            //alert(JSON.stringify(args));
            let date = new Date(args.dateStr);
            let year = date.getFullYear()
            let month = date.getMonth() + 1
            let day = date.getDate()

            let selectDate = "날짜: " + year + "/" + month + "/" + day;
            alert(selectDate);
        },
        onEventAdded(event) {            
            this.calendarOptions.events.push({
                title: '이사장님과 약속',
                start: '2024-09-13 12:30:00',
                constraint: '일식약속'
            });
        }
    },
}
</script>
<style scoped>
.calendar {
    width: 1000px;
    margin: 0 auto;
    margin-top: 30px;
    margin-bottom: 30px;
}
</style>
