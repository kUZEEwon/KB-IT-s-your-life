<template>
  <div id="app">
    <!-- header-->
    <header>

    </header>

    <!-- navbar -->
    <nav class="navbar navbar-expand-md navbar-dark bg-info sticky-top">
      <div class='container text-center'>      

        <div class="collapse navbar-collapse justify-content-between" id="collapsibleNavbar">        
          <ul class="navbar-nav">            
            <li class="nav-item">                
              <a href="/" class='nav-link'>Home</a>       
            </li>            
            <li class="nav-item">                
              <a href="/bbslist" class='nav-link' to="/bbslist">게시판</a>        
            </li>                  
            <li class="nav-item">                
              <a href="/calendar" class='nav-link' to="/calendar">일정관리</a>      
            </li> 
            <li class="nav-item">                
              <a href="/fileupdown" class='nav-link' to="/fileupdown">파일처리</a>      
            </li>
            <li class="nav-item">                
              <a href="/scrlist" class='nav-link' to="/scrlist">게시판2</a>      
            </li> 
          </ul>  

          <ul class="navbar-nav">
            <li class="nav-item">                
              <a href="/login" class='nav-link' to="/login">Login</a>      
            </li>        
          </ul>             
        </div>
      </div>
    </nav>

    <!-- Main -->
    <Main />

    <!-- footer -->
    <footer className="py-4 bg-info mt-auto">
    <!-- <footer className="py-4 bg-info text-light mt-auto"> -->
      <div className="container text-center">
        <ul className="nav justify-content-center mb-3">

          <li className='nav-item'>
            <a className='nav-link' href='/'>Top</a>
          </li>

        </ul>
        <p>
          <small>Copyright &copy;Graphic Arts</small>
        </p>
      </div>  
    </footer>

  </div>
</template>

<script>
import Main from "./views/Main.vue";

export default{
  name:'App',
  components:{
    Main
  }
}
</script>

<style>
#app {
  margin:0 auto;
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  color: #2c3e50;
} 

a {
  text-decoration: none !important;
}

header{
  margin:0 auto;
  background-image: url("./assets/header.jpg");
  background-position: center center;
  width: 2000px;
  height: 120px;
  background-size : cover;
} 

/* 네비바의 간격 조절 */
.navbar-nav > li{  
  padding-left:20px;
  padding-right:20px;
}
</style>
